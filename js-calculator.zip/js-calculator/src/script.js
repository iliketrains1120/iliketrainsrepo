//addition
var add1 = (0);
var add2 = (0);
var add3 = (0);
var addTotal = (add1 + add2 + add3);
document.write(addTotal + "<br>");
//subtraction
var sub1 = (0);
var sub2 = (0);
var sub3 = (0);
var subTotal = (sub1 - sub2 - sub3);
document.write(subTotal + "<br>");
//multiplication
var mul1 = (0);
var mul2 = (0);
var mul3 = (0);
var mulTotal = (mul1 * mul2 * mul3);
document.write(mulTotal + "<br>");
//division
var div1 = (0);
var div2 = (0);
var div3 = (0);
var divTotal = (div1 / div2 / div3);
document.write(divTotal + "<br>");
//remainder
var rem1 = (0);
var rem2 = (0);
var remTotal = (rem1 % rem2);
document.write(remTotal + "<br>");
//square root
var sqrt = (0);
var sqrtTotal = (sqrt / sqrt);
document.write(sqrtTotal + "<br>");
//power of 2
var pow = (2);
var powTotal = (pow * pow);
document.write(powTotal + "<br>")
//power of 3
var pow = (2);
var powTotal = (pow * pow * pow + "<br>");
document.write(powTotal);
//power of 4
var pow = (2);
var powTotal = (pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 5
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 6
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 7
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 8
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 9
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//power of 10
var pow = (2);
var powTotal = (pow * pow * pow * pow * pow * pow * pow * pow * pow * pow);
document.write(powTotal + "<br>");
//circumference
var diameter = (5); //inch
var circumference = (diameter * 3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679);
document.write(circumference + "<br>");
//factorials
var factorial = (52 * 51 * 50 * 49 * 48 * 47 * 46 * 45 * 44 * 43 * 42 * 41 * 40 * 39 * 38 * 37 * 36 * 35 * 34 * 33 * 32 * 31 * 30 * 29 * 28 * 27 * 26 * 25 * 24 * 23 * 22 * 21 * 20 * 19 * 18 * 17 * 16 * 15 * 14 * 13 * 12 * 11 * 10 * 9 * 8 * 7 * 6 * 5 * 4 * 3 * 2 * 1); //how many combinations you can make with a deck of cards
document.write(factorial);