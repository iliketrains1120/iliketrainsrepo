window.alert("I bet you have no idea what's going on right now.");
window.alert("I do.");
window.alert("Basically...");
window.alert("...Someone. This someone you know, this someone is near you, perhaps in the same room as you at this very moment.")
window.alert("This someone put a program on your computer...");
window.alert("...a Javascript program...");
window.alert("...one that makes messages appear on your screen.");
window.alert("Your computer has not been hacked remotely, but from this very computer.");
window.alert("This is nothing to report, as the only way this will happen again is if you find the program and hit run again.");
window.alert("This program does not in any way harm your computer, quite frankly, it is just a joke.");
window.alert("If you plan on finding who did this, all I will say is...");
window.alert("...good luck!");