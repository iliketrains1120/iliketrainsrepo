//writing text
document.write("Hello Anatoli <br>");
//"<br>" is the equivilent of hitting "enter"
//variables
var myvar = "variable intensifies";
//concatination
var words = "This is ";
var morewords = "a sentence. <br>";
var sentence = words + morewords;
document.write(sentence);
//math
var num1 = 10;
var num2 = 2;
var total = num1 + num2; //addition
var total = num1 - num2; //subtraction
var total = num1 * num2; //multiplication
var total = num1 / num2; //division
var total = num1 % num2; //find remainder
document.write(total);
//strings
var alpha = "EA Sports";
var length = alpha.length; //find length of string
document.write(length);
var result = alpha.substring(0, 3);
//arrays
var myArray = new Array(4); //an array holds multiple variables
myarray[0] = "It's ";
myarray[1] = "in ";
myarray[2] = "the ";
myarray[3] = "game";
document.write(myArray[0]);
var myArray2 = new Array("E", "A", "Sports");
document.write(myArray2[1]);
//functions
function sayHello() {
  document.write("Hello");
}
//if and else
var a = 7;
if (a > 10) {
  window.alert(a); //will only be executed if the condition is true
} else {
  window.alert("The condition was false"); //will only be executed if the condition is false
}
//for loops
for (i = 0;i<10;i++) {
  document.write("This is iteration " + i);
}