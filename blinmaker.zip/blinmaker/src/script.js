package blinmaker;

public class cooker {
  
  public static void main(string[] args) {
    int eggsAmount;
    int eggsMin = 1;
    int milkAmount;
    int milkMin = 200; //milliliter
    int flourAmount;
    int flourMin = 100; //grams
    
    system.out.println("Hello Boris!");
    system.out.println("Blinmaker is starting up..");
    system.out.println("How many eggs you have?");
    
    scanner userInput;
    userInput = new scanner(system.in);
    eggsAmount = userInput.nextInt();
    system.out.println("You have " + eggsAmount + " eggs");
    
    system.out.println("How much milk you have?");
    userInput = new scanner(system.in);
    milkAmount = userInput.nextInt();
    system.out.println("You have " + milkAmount + "ml of milk");
    
    //main code
    system.out.println("How much flour you have?");
    userInput = new scanner(system.in);
    flourAmount = userInput.nextInt();
    system.out.println("You have " + flourAmount + "g of flour");
    
    if (eggsAmount < eggsMin || milkAmount < milkMin || flourAmount < flourMin:);
        system.out.println("no blin today :(");
  } else {
    //calculation
    flourAmount = flourAmount / flourMin;
    system.out.println("You have " + flourAmount + " portions of flour");
    
    milkAmount = milkAmount / milkMin;
    system.out.println("You have " + milkAmount + " portions of milk");
    
    //find smallest number of all 3
    int smallest;
    if (eggsAmount <= milkAmount && milkAmount <= flourAmount) {
      smallest = eggsAmount;
    } else if { (milkAmount <= flourAmount && milkAmount <= eggsAmount) {
      smallest = milkAmount;
    } else {
      smallest = flourAmount;
    }
               system.out.println(" ") // every portion is 4 blins
               system.out.println("You can make " + smallest*4 + " of blins");
               system.out.println(" ");
               system.out.println("You will need " + smallest*eggsMin + " eggs");
               system.out.println("You will need " + smallest*flourMin + " flour");
               system.out.println("You will need " + smallest*milkMin + " milk");
               system.out.println(" ");
               system.out.println("Blinmaker shutting down..");    
  }

}